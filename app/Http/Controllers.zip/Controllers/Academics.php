<?php

namespace App\Http\Controllers;
error_reporting(0);
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Academics extends Controller
{
   
}
